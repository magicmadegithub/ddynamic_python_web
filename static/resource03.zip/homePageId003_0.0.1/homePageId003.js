//处理返回的数据结构
function handleData(event, data) {
    var resultMap = {};
    resultMap["event"] = event;
    resultMap["data"] = data;
    var resultJson = JSON.stringify(resultMap);
    return resultJson;
}

//点击事件处理
function clickWidget(params) {
    var paramsMap = JSON.parse(params);
    var index = paramsMap["index"];

    var event = "click";
    var data = {};
    var dataParams = {};

    var url = "dahai://page" + index;
    data["url"] = url;
    data["params"] = dataParams;

    var result = handleData(event, data);
    return result;
}

//widget重新构建
function rebuildWidget(params) {
    var paramsMap = JSON.parse(params);
    if(platform == "android") {
       androidToNative.invoke(null, "widget重新构建");
    } else if (platform == "iOS"){
       DDynamicInvoke(result);
    }
}



//请求网络
function requestNet(params) {
     var paramsMap = JSON.parse(params);
     var identifier = paramsMap["identifier"];
     var event = "net";
     var data = {};
     var dataParams = {};
     dataParams["test"] = "abc";
     data["url"] = "http://122.51.125.14:5000/dynamicRefresh";
     data["method"] = "get";
     data["params"] = dataParams;
     data["identifier"] = identifier;
     var result = handleData(event, data);
     if(platform == "android") {
        androidToNative.invoke(null, result);
     } else if (platform == "iOS"){
        DDynamicInvoke(result);
     }
}